import * as vscode from "vscode";
import type { BranchTreeNode, DoctorReport } from "gitwe";
import { getContainer, getSettings, pickWorkspaceFolder } from "../gitweClient";
import { showGitweError } from "../util/errors";

interface BranchTypeSummary {
  name: string;
  prefix: string;
  baseBranch: string;
  mergeTargets: string[];
  autoTag: boolean;
  branchCount: number;
}

interface DashboardData {
  workflowName: string;
  currentBranch: string;
  workingTreeClean: boolean;
  totalBranches: number;
  branchTypes: BranchTypeSummary[];
  tree: BranchTreeNode;
  doctor: DoctorReport | undefined;
  error: string | undefined;
  updatedAt: number;
}

type InboundMessage =
  | { type: "ready" }
  | { type: "refresh" }
  | { type: "runDoctor" }
  | { type: "start" }
  | { type: "finish"; branch: string }
  | { type: "checkout"; branch: string }
  | { type: "deleteBranch"; branch: string }
  | { type: "openConfig" }
  | { type: "pull" }
  | { type: "push" };

/**
 * Singleton webview panel — a visual dashboard on top of the same handlers
 * the tree view and commands use. It doesn't duplicate any gitwe logic:
 * mutating actions (start/finish/checkout/delete/pull/push) are delegated
 * straight back to the registered VS Code commands, and this panel just
 * re-fetches + re-renders afterwards.
 */
export class GitwePanel {
  private static current: GitwePanel | undefined;

  static show(context: vscode.ExtensionContext, outputChannel: vscode.OutputChannel): void {
    if (GitwePanel.current) {
      GitwePanel.current.panel.reveal();
      return;
    }
    const panel = vscode.window.createWebviewPanel("gitweDashboard", "Gitwe Dashboard", vscode.ViewColumn.One, {
      enableScripts: true,
      retainContextWhenHidden: true,
    });
    panel.iconPath = {
      light: vscode.Uri.joinPath(context.extensionUri, "media", "activitybar-icon.svg"),
      dark: vscode.Uri.joinPath(context.extensionUri, "media", "activitybar-icon.svg"),
    };
    GitwePanel.current = new GitwePanel(panel, context, outputChannel);
  }

  private constructor(
    private readonly panel: vscode.WebviewPanel,
    context: vscode.ExtensionContext,
    private readonly outputChannel: vscode.OutputChannel,
  ) {
    this.panel.webview.html = this.renderShell();
    this.panel.onDidDispose(() => (GitwePanel.current = undefined), null, context.subscriptions);
    this.panel.webview.onDidReceiveMessage((message: InboundMessage) => this.handleMessage(message));
  }

  private async handleMessage(message: InboundMessage): Promise<void> {
    switch (message.type) {
      case "ready":
      case "refresh":
        await this.postData();
        return;
      case "runDoctor":
        await vscode.commands.executeCommand("gitwe.doctor");
        await this.postData();
        return;
      case "start":
        await vscode.commands.executeCommand("gitwe.start");
        await this.postData();
        return;
      case "finish":
        await vscode.commands.executeCommand("gitwe.finish", message.branch);
        await this.postData();
        return;
      case "checkout":
        await vscode.commands.executeCommand("gitwe.checkoutBranch", message.branch);
        await this.postData();
        return;
      case "deleteBranch":
        await vscode.commands.executeCommand("gitwe.deleteBranch", message.branch);
        await this.postData();
        return;
      case "openConfig":
        await vscode.commands.executeCommand("gitwe.openConfig");
        return;
      case "pull":
        await vscode.commands.executeCommand("gitwe.pull");
        await this.postData();
        return;
      case "push":
        await vscode.commands.executeCommand("gitwe.push");
        await this.postData();
        return;
    }
  }

  private async postData(): Promise<void> {
    const data = await this.loadData();
    void this.panel.webview.postMessage({ type: "data", payload: data });
  }

  private async loadData(): Promise<DashboardData> {
    const folder = pickWorkspaceFolder();
    const empty: DashboardData = {
      workflowName: "",
      currentBranch: "",
      workingTreeClean: true,
      totalBranches: 0,
      branchTypes: [],
      tree: { name: "main", isCurrent: false, children: [] },
      doctor: undefined,
      error: undefined,
      updatedAt: Date.now(),
    };
    if (!folder) return { ...empty, error: "Open a folder with a git repository." };

    const container = getContainer(folder, this.outputChannel);
    try {
      const [currentBranch, workingTreeClean, statusReport, branches, doctor] = await Promise.all([
        container.git.getCurrentBranch(),
        container.git.isWorkingTreeClean(),
        container.getStatusHandler.handle({ rootBranch: getSettings().defaultRootBranch }),
        container.listBranchesHandler.handle(),
        container.doctorHandler.handle().catch(() => undefined),
      ]);

      const branchTypes: BranchTypeSummary[] = container.workflow.branchTypes.map((rule) => ({
        name: rule.name,
        prefix: rule.prefix,
        baseBranch: rule.baseBranch,
        mergeTargets: [...rule.mergeTargets],
        autoTag: Boolean(rule.autoTag),
        branchCount: branches.filter((b) => b.name.startsWith(rule.prefix)).length,
      }));

      return {
        workflowName: container.workflow.name,
        currentBranch,
        workingTreeClean,
        totalBranches: branches.length,
        branchTypes,
        tree: statusReport.tree,
        doctor,
        error: undefined,
        updatedAt: Date.now(),
      };
    } catch (error) {
      await showGitweError(error, this.outputChannel);
      return { ...empty, error: error instanceof Error ? error.message : String(error) };
    }
  }

  private renderShell(): string {
    const nonce = String(Date.now());
    return /* html */ `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';" />
<title>Gitwe Dashboard</title>
<style>
  :root { color-scheme: light dark; }
  * { box-sizing: border-box; }
  body {
    font-family: var(--vscode-font-family);
    font-size: var(--vscode-font-size, 13px);
    color: var(--vscode-foreground);
    background: var(--vscode-editor-background);
    margin: 0;
    padding: 20px 28px 40px;
  }
  .icon { width: 14px; height: 14px; stroke: currentColor; fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; vertical-align: -2px; flex: none; }
  .icon svg { width: 100%; height: 100%; display: block; }
  .icon-lg { width: 20px; height: 20px; }

  /* ---------- header ---------- */
  header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    flex-wrap: wrap;
    margin-bottom: 18px;
  }
  .title-block h1 {
    font-size: 1.3em;
    font-weight: 600;
    margin: 0 0 4px;
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .subtitle {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    color: var(--vscode-descriptionForeground);
    font-size: 0.92em;
  }
  .pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 2px 10px;
    border-radius: 999px;
    font-size: 0.85em;
    font-weight: 500;
    background: var(--vscode-badge-background);
    color: var(--vscode-badge-foreground);
    white-space: nowrap;
  }
  .pill.clean { background: color-mix(in srgb, #3fb950 22%, transparent); color: #3fb950; }
  .pill.dirty { background: color-mix(in srgb, #d29922 22%, transparent); color: #d29922; }
  .pill.healthy { background: color-mix(in srgb, #3fb950 22%, transparent); color: #3fb950; }
  .pill.unhealthy { background: color-mix(in srgb, #f85149 22%, transparent); color: #f85149; }
  .pill.neutral { background: var(--vscode-badge-background); color: var(--vscode-badge-foreground); }

  .toolbar { display: flex; gap: 8px; flex-wrap: wrap; }
  button {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--vscode-button-secondaryBackground);
    color: var(--vscode-button-secondaryForeground);
    border: 1px solid var(--vscode-button-border, transparent);
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.92em;
    font-family: inherit;
    transition: background 0.1s ease;
  }
  button:hover { background: var(--vscode-button-secondaryHoverBackground); }
  button:active { transform: translateY(1px); }
  button.primary { background: var(--vscode-button-background); color: var(--vscode-button-foreground); }
  button.primary:hover { background: var(--vscode-button-hoverBackground); }
  button.icon-only { padding: 6px; }
  button:disabled { opacity: 0.5; cursor: default; }

  /* ---------- error / empty ---------- */
  .banner {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 14px;
    border-radius: 6px;
    background: color-mix(in srgb, #f85149 14%, transparent);
    color: var(--vscode-errorForeground);
    border: 1px solid color-mix(in srgb, #f85149 35%, transparent);
    margin-bottom: 18px;
    font-size: 0.92em;
  }
  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    gap: 10px;
    padding: 60px 20px;
    color: var(--vscode-descriptionForeground);
  }
  .empty-state .icon-lg { width: 32px; height: 32px; opacity: 0.6; }

  /* ---------- stat cards ---------- */
  .stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin: 18px 0 24px;
  }
  .stat-card {
    background: var(--vscode-editorWidget-background, var(--vscode-sideBar-background));
    border: 1px solid var(--vscode-widget-border, var(--vscode-panel-border, transparent));
    border-radius: 8px;
    padding: 12px 14px;
  }
  .stat-card .label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.78em;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--vscode-descriptionForeground);
    margin-bottom: 6px;
  }
  .stat-card .value { font-size: 1.15em; font-weight: 600; overflow-wrap: anywhere; }
  .stat-card .value.small { font-size: 0.95em; font-weight: 500; }

  section { margin: 26px 0; }
  h2 {
    font-size: 0.82em;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--vscode-descriptionForeground);
    margin: 0 0 10px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .layout { display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 26px; align-items: start; }
  @media (max-width: 760px) { .layout { grid-template-columns: 1fr; } }

  /* ---------- branch types ---------- */
  .type-list { display: flex; flex-direction: column; gap: 8px; }
  .type-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 12px;
    border-radius: 6px;
    background: var(--vscode-editorWidget-background, var(--vscode-sideBar-background));
    border: 1px solid var(--vscode-widget-border, var(--vscode-panel-border, transparent));
  }
  .type-row .type-name { font-weight: 600; min-width: 90px; }
  .type-row .type-meta { color: var(--vscode-descriptionForeground); font-size: 0.85em; flex: 1; overflow-wrap: anywhere; }
  .type-row .type-count {
    font-size: 0.78em;
    background: var(--vscode-badge-background);
    color: var(--vscode-badge-foreground);
    border-radius: 999px;
    padding: 1px 8px;
    white-space: nowrap;
  }
  code {
    font-family: var(--vscode-editor-font-family, monospace);
    background: var(--vscode-textCodeBlock-background, rgba(127,127,127,0.15));
    padding: 1px 5px;
    border-radius: 3px;
  }

  /* ---------- doctor checks ---------- */
  .check-list { display: flex; flex-direction: column; gap: 6px; }
  .check-row { display: flex; align-items: flex-start; gap: 8px; font-size: 0.88em; padding: 6px 10px; border-radius: 6px; background: var(--vscode-editorWidget-background, var(--vscode-sideBar-background)); }
  .check-row.pass .icon { stroke: #3fb950; }
  .check-row.fail .icon { stroke: #f85149; }
  .check-row .check-detail { color: var(--vscode-descriptionForeground); display: block; margin-top: 2px; }

  /* ---------- branch graph ---------- */
  ul.tree, ul.tree ul { list-style: none; margin: 0; padding-left: 20px; }
  ul.tree { padding-left: 0; }
  ul.tree > li { padding-left: 0; }
  .branch-row {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 8px;
    border-radius: 5px;
    border-left: 2px solid transparent;
  }
  .branch-row:hover { background: var(--vscode-list-hoverBackground); }
  .branch-row .branch-name { flex: 1; overflow-wrap: anywhere; cursor: pointer; }
  .branch-row .branch-name:hover { text-decoration: underline; }
  .branch-row.current { border-left-color: var(--vscode-textLink-foreground); background: var(--vscode-list-inactiveSelectionBackground); }
  .branch-row.current .branch-name { font-weight: 600; color: var(--vscode-textLink-foreground); }
  .branch-actions { display: none; gap: 4px; }
  .branch-row:hover .branch-actions { display: flex; }
  .branch-actions button { padding: 3px 6px; font-size: 0.8em; }

  .updated-at { color: var(--vscode-descriptionForeground); font-size: 0.8em; margin-top: 30px; text-align: right; }

  .skeleton { animation: pulse 1.4s ease-in-out infinite; background: var(--vscode-editorWidget-background, var(--vscode-sideBar-background)); border-radius: 6px; }
  @keyframes pulse { 0%, 100% { opacity: 0.5; } 50% { opacity: 1; } }
</style>
</head>
<body>
  <header>
    <div class="title-block">
      <h1>${icon("git-branch", "icon-lg")} Gitwe Dashboard</h1>
      <div class="subtitle" id="subtitle">
        <span class="pill neutral" id="workflow-pill">…</span>
        <span class="pill neutral" id="branch-pill">…</span>
        <span class="pill neutral" id="health-pill">…</span>
      </div>
    </div>
    <div class="toolbar">
      <button class="primary" id="start">${icon("plus-circle")} Start Branch</button>
      <button id="pull">${icon("arrow-down")} Pull</button>
      <button id="push">${icon("arrow-up")} Push</button>
      <button id="doctor">${icon("activity")} Doctor</button>
      <button id="config">${icon("settings")} Config</button>
      <button class="icon-only" id="refresh" title="Refresh">${icon("refresh-cw")}</button>
    </div>
  </header>

  <div id="error-banner" class="banner" style="display:none">
    ${icon("alert-triangle")} <span id="error-text"></span>
  </div>

  <div id="content">
    <div class="empty-state">
      <div class="skeleton" style="width:100%;height:80px;"></div>
    </div>
  </div>

<script nonce="${nonce}">
  const vscode = acquireVsCodeApi();

  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.entries(props).forEach(([k, v]) => {
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k === "html") node.innerHTML = v;
      else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    });
    children.forEach((c) => node.appendChild(c));
    return node;
  }

  const ICONS = ${JSON.stringify(ICONS)};
  function iconEl(name, extraClass) {
    const span = document.createElement("span");
    span.className = "icon" + (extraClass ? " " + extraClass : "");
    span.style.display = "inline-flex";
    span.innerHTML = ICONS[name] || "";
    return span;
  }

  function renderBranchRow(node) {
    const li = el("li");
    const row = el("div", { class: "branch-row" + (node.isCurrent ? " current" : "") });
    row.appendChild(iconEl(node.isCurrent ? "check-circle" : "git-commit"));
    const nameSpan = el("span", { class: "branch-name", text: node.name });
    nameSpan.addEventListener("click", () => {
      if (!node.isCurrent) vscode.postMessage({ type: "checkout", branch: node.name });
    });
    row.appendChild(nameSpan);
    if (!node.isCurrent && node.name !== "main" && node.name !== "develop" && node.name !== "master") {
      const actions = el("div", { class: "branch-actions" });
      const finishBtn = el("button", { title: "Finish" }, [iconEl("check")]);
      finishBtn.addEventListener("click", (e) => { e.stopPropagation(); vscode.postMessage({ type: "finish", branch: node.name }); });
      const deleteBtn = el("button", { title: "Delete" }, [iconEl("trash-2")]);
      deleteBtn.addEventListener("click", (e) => { e.stopPropagation(); vscode.postMessage({ type: "deleteBranch", branch: node.name }); });
      actions.appendChild(finishBtn);
      actions.appendChild(deleteBtn);
      row.appendChild(actions);
    }
    li.appendChild(row);
    if (node.children && node.children.length > 0) {
      const ul = el("ul", { class: "tree" });
      node.children.forEach((child) => ul.appendChild(renderBranchRow(child)));
      li.appendChild(ul);
    }
    return li;
  }

  function statCard(label, value, iconName, small) {
    return el("div", { class: "stat-card" }, [
      el("div", { class: "label" }, [iconEl(iconName), document.createTextNode(label)]),
      el("div", { class: "value" + (small ? " small" : ""), text: value }),
    ]);
  }

  function render(data) {
    const errorBanner = document.getElementById("error-banner");
    const noRepo = data.error && !data.currentBranch;
    if (data.error) {
      errorBanner.style.display = noRepo ? "none" : "flex";
      document.getElementById("error-text").textContent = data.error;
    } else {
      errorBanner.style.display = "none";
    }

    document.getElementById("workflow-pill").innerHTML = "";
    document.getElementById("workflow-pill").appendChild(iconEl("layers"));
    document.getElementById("workflow-pill").appendChild(document.createTextNode(" " + (data.workflowName || "—")));

    const branchPill = document.getElementById("branch-pill");
    branchPill.className = "pill " + (data.currentBranch ? (data.workingTreeClean ? "clean" : "dirty") : "neutral");
    branchPill.innerHTML = "";
    branchPill.appendChild(iconEl(data.workingTreeClean ? "check-circle" : "circle"));
    branchPill.appendChild(document.createTextNode(" " + (data.currentBranch || "no branch") + (data.currentBranch ? (data.workingTreeClean ? " · clean" : " · uncommitted") : "")));

    const healthPill = document.getElementById("health-pill");
    if (data.doctor) {
      healthPill.className = "pill " + (data.doctor.healthy ? "healthy" : "unhealthy");
      healthPill.innerHTML = "";
      healthPill.appendChild(iconEl(data.doctor.healthy ? "shield-check" : "shield-alert"));
      const failed = data.doctor.checks.filter((c) => !c.passed).length;
      healthPill.appendChild(document.createTextNode(data.doctor.healthy ? " Healthy" : " " + failed + " issue(s)"));
    } else {
      healthPill.className = "pill neutral";
      healthPill.innerHTML = "";
      healthPill.appendChild(iconEl("help-circle"));
      healthPill.appendChild(document.createTextNode(" Unknown"));
    }

    const content = document.getElementById("content");
    content.innerHTML = "";

    if (noRepo) {
      content.appendChild(el("div", { class: "empty-state" }, [
        iconEl("folder", "icon-lg"),
        el("div", { text: data.error }),
      ]));
      return;
    }

    const stats = el("div", { class: "stats" }, [
      statCard("Current branch", data.currentBranch || "—", "git-branch", true),
      statCard("Total branches", String(data.totalBranches), "git-commit"),
      statCard("Working tree", data.workingTreeClean ? "Clean" : "Uncommitted changes", "file-text", true),
      statCard("Branch types", String((data.branchTypes || []).length), "layers"),
    ]);
    content.appendChild(stats);

    const layout = el("div", { class: "layout" });

    const left = el("div");
    const graphSection = el("section");
    graphSection.appendChild(el("h2", {}, [iconEl("git-merge"), document.createTextNode("Branch Graph")]));
    const treeRoot = el("ul", { class: "tree" });
    if (data.tree) treeRoot.appendChild(renderBranchRow(data.tree));
    graphSection.appendChild(treeRoot);
    left.appendChild(graphSection);

    const right = el("div");

    const typesSection = el("section");
    typesSection.appendChild(el("h2", {}, [iconEl("layers"), document.createTextNode("Branch Types")]));
    const typeList = el("div", { class: "type-list" });
    (data.branchTypes || []).forEach((t) => {
      const meta = t.prefix + " → " + t.mergeTargets.join(", ") + (t.autoTag ? " · tagged" : "");
      typeList.appendChild(el("div", { class: "type-row" }, [
        el("span", { class: "type-name", text: t.name }),
        el("span", { class: "type-meta", text: meta }),
        el("span", { class: "type-count", text: t.branchCount + (t.branchCount === 1 ? " branch" : " branches") }),
      ]));
    });
    if (!(data.branchTypes || []).length) {
      typeList.appendChild(el("div", { class: "type-meta", text: "No branch types configured." }));
    }
    typesSection.appendChild(typeList);
    right.appendChild(typesSection);

    if (data.doctor) {
      const doctorSection = el("section");
      doctorSection.appendChild(el("h2", {}, [iconEl("activity"), document.createTextNode("Health Checks")]));
      const checkList = el("div", { class: "check-list" });
      data.doctor.checks.forEach((c) => {
        const row = el("div", { class: "check-row " + (c.passed ? "pass" : "fail") });
        row.appendChild(iconEl(c.passed ? "check-circle" : "x-circle"));
        const textWrap = el("div");
        textWrap.appendChild(el("span", { text: c.name }));
        if (c.detail) textWrap.appendChild(el("span", { class: "check-detail", text: c.detail }));
        row.appendChild(textWrap);
        checkList.appendChild(row);
      });
      doctorSection.appendChild(checkList);
      right.appendChild(doctorSection);
    }

    layout.appendChild(left);
    layout.appendChild(right);
    content.appendChild(layout);

    content.appendChild(el("div", {
      class: "updated-at",
      text: "Updated " + new Date(data.updatedAt).toLocaleTimeString(),
    }));
  }

  document.getElementById("start").addEventListener("click", () => vscode.postMessage({ type: "start" }));
  document.getElementById("pull").addEventListener("click", () => vscode.postMessage({ type: "pull" }));
  document.getElementById("push").addEventListener("click", () => vscode.postMessage({ type: "push" }));
  document.getElementById("doctor").addEventListener("click", () => vscode.postMessage({ type: "runDoctor" }));
  document.getElementById("config").addEventListener("click", () => vscode.postMessage({ type: "openConfig" }));
  document.getElementById("refresh").addEventListener("click", () => vscode.postMessage({ type: "refresh" }));

  window.addEventListener("message", (event) => {
    const message = event.data;
    if (message.type === "data") render(message.payload);
  });

  vscode.postMessage({ type: "ready" });
</script>
</body>
</html>`;
  }
}

/** Minimal feather-style inline icon set (no external resources, CSP-safe). */
const ICONS: Record<string, string> = {
  "git-branch": '<svg viewBox="0 0 24 24"><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>',
  "git-commit": '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><line x1="3" y1="12" x2="9" y2="12"/><line x1="15" y1="12" x2="21" y2="12"/></svg>',
  "git-merge": '<svg viewBox="0 0 24 24"><circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M6 21V9a9 9 0 0 0 9 9"/></svg>',
  "plus-circle": '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>',
  "arrow-down": '<svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>',
  "arrow-up": '<svg viewBox="0 0 24 24"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>',
  activity: '<svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
  settings: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
  "refresh-cw": '<svg viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
  "alert-triangle": '<svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  "check-circle": '<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
  "x-circle": '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
  "shield-check": '<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>',
  "shield-alert": '<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
  "help-circle": '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 2-3 4"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
  layers: '<svg viewBox="0 0 24 24"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  circle: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="currentColor" stroke="none"/></svg>',
  "file-text": '<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>',
  folder: '<svg viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  check: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>',
  "trash-2": '<svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
};

function icon(name: string, extraClass?: string): string {
  const svg = ICONS[name] || "";
  return svg.replace("<svg ", `<svg class="icon${extraClass ? " " + extraClass : ""}" `);
}
